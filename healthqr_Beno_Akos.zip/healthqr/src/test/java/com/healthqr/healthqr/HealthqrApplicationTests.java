package com.healthqr.healthqr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthqrApplicationTests {

	@Test
	void contextLoads() {
	}

}
