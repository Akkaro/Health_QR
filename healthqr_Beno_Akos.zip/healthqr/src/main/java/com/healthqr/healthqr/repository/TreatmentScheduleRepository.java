package com.healthqr.healthqr.repository;

import com.healthqr.healthqr.models.TreatmentSchedule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TreatmentScheduleRepository extends JpaRepository<TreatmentSchedule, Long> {

}
